class A{
	private:
		int a,b,c;
		A(){
			a = 2;
			b = 3;
			c = 4;
			cout<<"I'm A\n";
		}
	protected:
		float d;
	public:
		void giveOut(){
			cout<<"This is my func!";
		}
}

class B : private A{
private:
	int d;
	B(){
		cout<<"I'm B1\n";
	}
	B(int per){
		d = per;
		cout<<"I'm B2\n";
	}
public:
	void printVal(){
		cout<<"Value is:"<<d<<"\n";
	}
}

int main(){
	B test(1);
	B test2;
	return 0;
}